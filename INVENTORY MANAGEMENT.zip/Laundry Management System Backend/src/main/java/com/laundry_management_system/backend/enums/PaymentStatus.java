package com.laundry_management_system.backend.enums;

public enum PaymentStatus {
    PENDING,
    PAID,
    REFUNDED,
    FAILED
}
