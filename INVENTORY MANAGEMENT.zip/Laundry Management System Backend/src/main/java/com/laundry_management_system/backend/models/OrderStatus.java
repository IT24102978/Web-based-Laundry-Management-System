package com.laundry_management_system.backend.models;

public enum OrderStatus { RECEIVED, IN_PROCESS, READY, DELIVERED, CANCELLED }
