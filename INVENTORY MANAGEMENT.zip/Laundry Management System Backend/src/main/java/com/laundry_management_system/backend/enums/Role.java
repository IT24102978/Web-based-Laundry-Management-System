package com.laundry_management_system.backend.enums;

public enum Role {
    ADMIN,
    CUSTOMER,
    EMPLOYEE
}