package com.laundry_management_system.backend.services;

import com.laundry_management_system.backend.models.Inventory;
import com.laundry_management_system.backend.repositories.InventoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class InventoryService {

    private final InventoryRepository repo;

    public InventoryService(InventoryRepository repo) {
        this.repo = repo;
    }

    public Inventory add(Inventory item) {
        item.setUpdatedAt(LocalDateTime.now());
        return repo.save(item);
    }

    public List<Inventory> all() {
        return repo.findAll();
    }

    public Optional<Inventory> byId(Integer id) {
        return repo.findById(id);
    }

    public Inventory update(Integer id, Inventory item) {
        item.setItemId(id);
        item.setUpdatedAt(LocalDateTime.now());
        return repo.save(item);
    }

    public void delete(Integer id) {
        repo.deleteById(id);
    }

    // Fixed: Explicitly save after reducing stock
    public boolean reduceStock(Integer id, int qty) {
        Optional<Inventory> optItem = repo.findById(id);

        if (optItem.isEmpty()) {
            return false;
        }

        Inventory item = optItem.get();

        // Validate quantity
        if (qty <= 0 || item.getStockLevel() < qty) {
            return false;
        }

        // Update stock level
        item.setStockLevel(item.getStockLevel() - qty);
        item.setUpdatedAt(LocalDateTime.now());

        // Explicitly save the changes
        repo.save(item);

        return true;
    }

    // Fixed: Added better error handling
    public Inventory addStock(Integer id, int qty) {
        Inventory item = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found with id: " + id));

        if (qty <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }

        item.setStockLevel(item.getStockLevel() + qty);
        item.setUpdatedAt(LocalDateTime.now());

        return repo.save(item);
    }

    public List<Inventory> lowStockItems() {
        return repo.findAll().stream()
                .filter(item -> item.getStockLevel() <= item.getReorderThreshold())
                .toList();
    }
}