package com.laundry_management_system.backend.enums;

public enum Channel {
    SMS,
    EMAIL
}
