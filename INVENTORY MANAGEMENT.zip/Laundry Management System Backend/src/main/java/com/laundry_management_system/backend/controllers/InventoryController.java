package com.laundry_management_system.backend.controllers;

import com.laundry_management_system.backend.models.Inventory;
import com.laundry_management_system.backend.services.InventoryService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// ================= UI Controller =================
@Controller
@RequestMapping("/inventory")
public class InventoryController {

    private static final Logger log = LoggerFactory.getLogger(InventoryController.class);
    private final InventoryService service;

    public InventoryController(InventoryService service) {
        this.service = service;
    }

    @GetMapping
    public String inventoryPage(Model model) {
        log.info("Loading inventory page");
        model.addAttribute("inventoryItems", service.all());
        return "inventory";
    }

    @GetMapping("/edit")
    public String editPage(@RequestParam Integer id, Model model) {
        log.info("Loading edit page for item id: {}", id);
        service.byId(id).ifPresent(item -> model.addAttribute("item", item));
        return "inventory-edit";
    }
}

// ================= REST API Controller =================
@RestController
@RequestMapping("/api/inventory")
class InventoryRestController {

    private static final Logger log = LoggerFactory.getLogger(InventoryRestController.class);
    private final InventoryService service;

    public InventoryRestController(InventoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Inventory> create(@Valid @RequestBody Inventory item) {
        log.info("CREATE request received: {}", item);
        try {
            Inventory created = service.add(item);
            log.info("Item created successfully: {}", created);
            return ResponseEntity.ok(created);
        } catch (Exception e) {
            log.error("Error creating item", e);
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Inventory>> all() {
        log.info("GET ALL request received");
        return ResponseEntity.ok(service.all());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inventory> one(@PathVariable Integer id) {
        log.info("GET ONE request received for id: {}", id);
        return service.byId(id)
                .map(item -> {
                    log.info("Item found: {}", item);
                    return ResponseEntity.ok(item);
                })
                .orElseGet(() -> {
                    log.warn("Item not found with id: {}", id);
                    return ResponseEntity.notFound().build();
                });
    }

    @PutMapping("/{id}")
    public ResponseEntity<Inventory> update(
            @PathVariable Integer id,
            @Valid @RequestBody Inventory item) {
        log.info("UPDATE request received for id: {}, data: {}", id, item);
        if (service.byId(id).isEmpty()) {
            log.warn("Item not found for update, id: {}", id);
            return ResponseEntity.notFound().build();
        }
        Inventory updated = service.update(id, item);
        log.info("Item updated successfully: {}", updated);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Integer id) {
        log.info("DELETE request received for id: {}", id);
        if (service.byId(id).isEmpty()) {
            log.warn("Item not found for deletion, id: {}", id);
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        log.info("Item deleted successfully, id: {}", id);
        return ResponseEntity.ok("Item deleted successfully");
    }

    @PostMapping("/{id}/addStock")
    public ResponseEntity<String> addStock(
            @PathVariable Integer id,
            @RequestParam int quantity) {
        log.info("ADD STOCK request received - id: {}, quantity: {}", id, quantity);
        try {
            if (quantity <= 0) {
                log.warn("Invalid quantity: {}", quantity);
                return ResponseEntity.badRequest().body("Quantity must be positive");
            }
            Inventory updated = service.addStock(id, quantity);
            log.info("Stock added successfully. New stock level: {}", updated.getStockLevel());
            return ResponseEntity.ok("Stock updated: " + updated.getStockLevel());
        } catch (RuntimeException e) {
            log.error("Error adding stock for id: {}", id, e);
            return ResponseEntity.badRequest().body("Failed to add stock: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/reduceStock")
    public ResponseEntity<String> reduceStock(
            @PathVariable Integer id,
            @RequestParam int quantity) {
        log.info("REDUCE STOCK request received - id: {}, quantity: {}", id, quantity);
        try {
            if (quantity <= 0) {
                log.warn("Invalid quantity: {}", quantity);
                return ResponseEntity.badRequest().body("Quantity must be positive");
            }
            boolean success = service.reduceStock(id, quantity);
            if (success) {
                log.info("Stock reduced successfully for id: {}", id);
                return ResponseEntity.ok("Stock reduced successfully");
            } else {
                log.warn("Failed to reduce stock - insufficient stock or item not found, id: {}", id);
                return ResponseEntity.badRequest().body("Not enough stock or item not found");
            }
        } catch (Exception e) {
            log.error("Error reducing stock for id: {}", id, e);
            return ResponseEntity.badRequest().body("Failed to reduce stock: " + e.getMessage());
        }
    }

    @GetMapping("/lowStock")
    public ResponseEntity<List<Inventory>> lowStock() {
        log.info("LOW STOCK request received");
        List<Inventory> items = service.lowStockItems();
        log.info("Found {} low stock items", items.size());
        return ResponseEntity.ok(items);
    }
}