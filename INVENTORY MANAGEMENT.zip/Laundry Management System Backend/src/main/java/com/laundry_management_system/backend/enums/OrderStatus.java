package com.laundry_management_system.backend.enums;

public enum OrderStatus {
    RECEIVED,
    IN_PROCESS,
    READY,
    DELIVERED,
    CANCELLED
}
