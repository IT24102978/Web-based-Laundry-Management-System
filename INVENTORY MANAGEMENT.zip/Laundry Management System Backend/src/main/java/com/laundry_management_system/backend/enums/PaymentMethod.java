package com.laundry_management_system.backend.enums;

public enum PaymentMethod {
    CASH,
    CARD,
    ONLINE
}
