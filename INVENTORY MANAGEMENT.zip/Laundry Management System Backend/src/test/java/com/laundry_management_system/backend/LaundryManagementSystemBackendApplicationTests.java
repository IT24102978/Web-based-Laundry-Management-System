package com.laundry_management_system.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaundryManagementSystemBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
